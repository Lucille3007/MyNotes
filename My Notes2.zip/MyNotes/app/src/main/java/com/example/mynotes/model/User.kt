package com.example.mynotes.model

data class User(val name: String, val listNotes: ArrayList<Note>)
