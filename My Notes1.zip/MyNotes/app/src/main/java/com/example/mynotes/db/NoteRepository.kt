package com.example.mynotes.db

import android.app.Application
import com.example.mynotes.model.Note

class NoteRepository(application: Application) {

    private var noteDao: NoteDao?

    init {
        val db = NoteDB.invoke(application.applicationContext)
        noteDao = db?.getNotesDao()
    }


    fun getAllNotes() = noteDao?.getAllNotes()

    fun searchNote(query: String?) = noteDao?.searchNote(query)

    suspend fun addNote(note: Note) {
        noteDao?.addNote(note)
    }

    suspend fun deleteNote(note: Note) {
        noteDao?.deleteNote(note)
    }

    suspend fun updateNote(note: Note) {
        noteDao?.updateNote(note)
    }

}